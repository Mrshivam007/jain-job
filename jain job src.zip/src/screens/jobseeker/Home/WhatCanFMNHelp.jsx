// import React from "react";
// import "react-responsive-carousel/lib/styles/carousel.min.css";
// import { Carousel } from "react-responsive-carousel";
// import { ImQuotesLeft } from "react-icons/im";
// import "../../../css/jobseeker/WhatCanFMNHelpCrousel.css";
// import Refer from "./Refer";
// import CreateCard from "./CreateCard";
// import Example from "./VerticalCrousel/Example.js";

// export default function WhatCanFMNHelp() {
//   return (
//     <div className="WhatFmn_container">
//       <div className="whatfmncanhelp_content">
//         <div className="WhatClientSays-Head">
//         </div>
//         <Example/>
//       </div>
//     </div>
//   );
// }
