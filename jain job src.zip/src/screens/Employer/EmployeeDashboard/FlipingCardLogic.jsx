import React from "react"

const FlipingCardLogic = () =>{
    return(
        <>
        <div>
            kalta logic box

        </div>
        </>
    )

}

export default FlipingCardLogic;