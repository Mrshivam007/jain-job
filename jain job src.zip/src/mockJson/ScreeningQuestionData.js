const Data = [
    {
        questionNo: "Q.1",
        question: "Tell me about yourself....",
    
    },
    {
        questionNo: "Q.2",
        question: "Why are you searching for a job?",
    
    },
    {
        questionNo: "Q.3",
        question: "Why did you apply for this position?         ",
    
    },
    {
        questionNo: "Q.4",
        question: "Why do you want this job?        ",
    
    },
    {
        questionNo: "Q.5",
        question: "Why do you want to work here?        ",
    
    },
    {
        questionNo: "Q.6",
        question: "What do you know about this role?        ",
    
    },
    {
        questionNo: "Q.7",
        question: "What are you passionate about?        ",
    
    },

]

export default Data;