const Data = [
    {
        Name:"Fullstack  Developer",
        Experience:"2-3 Years of experience",
        JobMode:"Work From Home",
        Skills:"Html, css ,Angular,Dreamweaver, bootstrap,Jquery",
        Income:"20000-30000/ Month",
    },
    {
        Name:"Fullstack  Developer",
        Experience:"2-3 Years of experience",
        JobMode:"Work From Home",
        Skills:"Html, css ,Angular,Dreamweaver, bootstrap,Jquery",
        Income:"20000-30000/ Month",
    },
    {
        Name:"Fullstack  Developer",
        Experience:"2-3 Years of experience",
        JobMode:"Work From Home",
        Skills:"Html, css ,Angular,Dreamweaver, bootstrap,Jquery",
        Income:"20000-30000/ Month",
    },
    {
        Name:"Fullstack  Developer",
        Experience:"2-3 Years of experience",
        JobMode:"Work From Home",
        Skills:"Html, css ,Angular,Dreamweaver, bootstrap,Jquery",
        Income:"20000-30000/ Month",
    },
    {
        Name:"Fullstack  Developer",
        Experience:"2-3 Years of experience",
        JobMode:"Work From Home",
        Skills:"Html, css ,Angular,Dreamweaver, bootstrap,Jquery",
        Income:"20000-30000/ Month",
    },
    {
        Name:"Fullstack  Developer",
        Experience:"2-3 Years of experience",
        JobMode:"Work From Home",
        Skills:"Html, css ,Angular,Dreamweaver, bootstrap,Jquery",
        Income:"20000-30000/ Month",
    },
    {
        Name:"Fullstack  Developer",
        Experience:"2-3 Years of experience",
        JobMode:"Work From Home",
        Skills:"Html, css ,Angular,Dreamweaver, bootstrap,Jquery",
        Income:"20000-30000/ Month",
    },
]
export default Data;