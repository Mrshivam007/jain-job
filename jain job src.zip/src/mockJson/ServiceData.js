import service01 from '../screens/Employer/EmployerHome/service01.png'
import service02 from '../screens/Employer/EmployerHome/service02.png'
import service03 from '../screens/Employer/EmployerHome/service03.png'
import service04 from '../screens/Employer/EmployerHome/service04.png'



const ServiceData = [
    {
        image:service01,
        Heading:'Profile Highlighter',
        content:'Grab the attention of employers',
    },
    {
        image:service02,
        Heading:'Resume Maker',
        content:'Grab the attention of employers',
    },
    {
        image:service03,
        Heading:'Featured Profile',
        content:'Grab the attention of employers',
    },
    {
        image:service04,
        Heading:'Career Booster',
        content:'Grab the attention of employers',
    },
    {
        image:service03,
        Heading:'Career Booster',
        content:'Grab the attention of employers',
    },
    {
        image:service03,
        Heading:'Career Booster',
        content:'Grab the attention of employers',
    },
]

export default ServiceData;