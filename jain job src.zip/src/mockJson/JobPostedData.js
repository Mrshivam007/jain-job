const Data=[
    {
    Job:'Fullstack Developer',
    date : 'Date: 16-5-2022',
    Company:'Tech Jain It Solution',
    JobType:'Work From Home',
    lang : 'Html, css ,Angular, Dreamweaver, bootstrap,Jquery',
    sal : '20000-30000/ Month',
    postdate : 'Posted on :16-5-2022',
    expireddate : 'Expired on :16-6-2022'
    },
    {
    Job:'Fullstack Developer',
    date : 'Date: 16-5-2022',
    Company:'Tech Jain It Solution',
    JobType:'Work From Home',
    lang : 'Html, css ,Angular, Dreamweaver, bootstrap,Jquery',
    sal : '20000-30000/ Month',
    postdate : 'Posted on :16-5-2022',
    expireddate : 'Expired on :16-6-2022'
    },
    {
    Job:'Fullstack Developer',
    date : 'Date: 16-5-2022',
    Company:'Tech Jain It Solution',
    JobType:'Work From Home',
    lang : 'Html, css ,Angular, Dreamweaver, bootstrap,Jquery',
    sal : '20000-30000/ Month',
    postdate : 'Posted on :16-5-2022',
    expireddate : 'Expired on :16-6-2022'
    },
    {
    Job:'Fullstack Developer',
    date : 'Date: 16-5-2022',
    Company:'Tech Jain It Solution',
    JobType:'Work From Home',
    lang : 'Html, css ,Angular, Dreamweaver, bootstrap,Jquery',
    sal : '20000-30000/ Month',
    postdate : 'Posted on :16-5-2022',
    expireddate : 'Expired on :16-6-2022'
    },
    
]
export default Data;
