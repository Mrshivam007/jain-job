const TrackData = [
    {
        PostName:"Fullstack  Developer",
        CompanyName:"Tech Jain It Solution",
        JobMode:"Work From Home",
        ApplyDate:"Applied on 1 May 2022",
        Status:"Not Selected",
    },
    {
        PostName:"Fullstack  Developer",
        CompanyName:"Tech Jain It Solution",
        JobMode:"Work From Home",
        ApplyDate:"Applied on 1 May 2022",
        Status:"Viewed a week ago",
   
    },
    {
        PostName:"Fullstack  Developer",
        CompanyName:"Tech Jain It Solution",
        JobMode:"Work From Home",
        ApplyDate:"Applied on 1 May 2022",
        Status:"Not Selected",

    },
]
    export default TrackData;
