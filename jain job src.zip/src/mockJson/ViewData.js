const Data = [
    {
Name:"Web/UI Designer",
        Company:"Ascentspark Software",
        Experience:"3+ years of experience",
        JobMode:"Work From Home",
        Location:"Salt Lake, Kolkata, West Bengal",
        Income:"20000-30000/ Month",
    },
]
export default Data;
// const Data = [
//     {
// Name:"Hiring For Full Stack Developer",
//         Company:"Techjain It Solution",
//         Experience:"3+ years of experience",
//         JobMode:"Work From Home",
//         Skills:"Html, css ,Angular,Dreamweaver, bootstrap,Jquery",
//         Income:"20000-30000/ Month",
//     },
// ]
// export default Data;
