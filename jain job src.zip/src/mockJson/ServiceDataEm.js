import service01 from '../screens/Employer/EmployerHome/service01.png'
import service02 from '../screens/Employer/EmployerHome/service02.png'
import service03 from '../screens/Employer/EmployerHome/service03.png'
import service04 from '../screens/Employer/EmployerHome/service04.png'



const ServiceDataEm = [
    {
        image:service01,
        Heading:'Tailored Resume',
        content:'Grab the attention of employers',
    },
    {
        image:service02,
        Heading:'Profile Building',
        content:'Grab the attention of employers',
    },
    {
        image:service03,
        Heading:'Promotion on FMN Stoy Club',
        content:'Grab the attention of employers',
    },
    {
        image:service04,
        Heading:'Career Booster',
        content:'Grab the attention of employers',
    },
    {
        image:service03,
        Heading:'Career Booster',
        content:'Grab the attention of employers',
    },
    {
        image:service03,
        Heading:'Career Booster',
        content:'Grab the attention of employers',
    },
]

export default ServiceDataEm;