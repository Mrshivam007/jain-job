const SubscriptionRows = [
            {
                Subject:'Get access to all premium and high priority jobs',
                
                Basic:false,
                Premium:true,
            },
            {
                Subject:'Ezy apply upto 2/7 jobs in a month',
                
                Basic:true,
                Premium:true,
            },
            {
                Subject:'Subscription fees    ',
                
                Basic:true,
                Premium:true,
            },
            {
                Subject:'Customized CV download /upload to drive',
                
                Basic:false,
                Premium:true,
            },
            {
                Subject:'General Evaluation test',
                
                Basic:false,
                Premium:true,
            },
            {
                Subject:'Personalised message to hiring managers.  ',
                Basic:false,
                Premium:true,
            },
            {
                Subject:'Referrals to be used while payment	',
        
                Basic:false,
                Premium:true,
            },
            {
                Subject:'Priority evaluation test.  ',
    
                Basic:false,
                Premium:true,
            },
]
export default SubscriptionRows;