const Data = [
    {
        name:'Akash Singh',
        company:'Techjain It Solutions',
        loc:'Jabalpur',
        lang:['Java' , 'Python', '.NET'],
        cer:'Adobe XD Certified', 
        Salary:'Salary: Negotiable', 
        Relocation:'Relocation: No',
    },
    
]
export default Data;